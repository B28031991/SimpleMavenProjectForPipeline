package test_maven;

public class JavaVersionTest {

	public static void main(String args[]) {
		System.out.println("Hi from Maven project");
	}
	
	
}
